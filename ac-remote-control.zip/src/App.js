import React from 'react';
import './App.css';
import './style/html5up-dimension/assets/css/fontawesome-all.min.css';

class App extends React.Component {
  constructor(props){
    super(props);
    this.state = {
      interval_heartbeat: 5000,
      interval_update_room_temp: 5000,
      is_checked_in: false,
      is_on: false,
      is_served: false,
      is_order_timer_on: false,
      room_id: "000",
      room_temp: 0.0,
      default_room_temp: 0,
      ac_wind: 1,
      ac_temp: 26.0,
      temp_min: 0,
      temp_max: 40,
      online_time: 0,
      checkin_time: "",
      power: 0,
      expense: 0,
      charge_policy: 0
    };
  }

  wind_int2str(wind) {
    switch (wind) {
      case 1: 
        return "low";
      case 2: 
        return "medium";
      case 3: 
        return "high";
      default:
        alert('Out of wind range!');
        return -1;
    }
  }

  wind_str2int(wind) {
    switch (wind) {
      case "low": 
        return 1;
      case "medium": 
        return 2;
      case "high": 
        return 3;
      default:
        alert('Out of wind range!');
        return -1;
    }
  }

  parse_res(res) {
    let json = JSON.parse(res.text);
    if (json.hasOwnProperty('Error')) {
      alert(json['Error'])
    } else {
      let room_id = json['room_id'];
      let ac_status = json['ac_status'];
      let ac_wind = this.state.ac_wind;
      let is_served = this.state.is_served;
      if (ac_status !== 'off') {
        is_served = true;
        ac_wind = this.wind_str2int(ac_status);
      }
      else {
        is_served = false;
      }
      let room_temp = json['temp'];
      let ac_temp = json['target_temp'];
      let power = json['elec'];
      let online_time = json['online_time'];
      let checkin_time = json['checkin_time'];
      let is_checked_in = json['checked'];
      let expense = json['total_money'];
      let charge_policy = json['price'];
      this.setState({
        is_checked_in: is_checked_in,
        is_served: is_served,
        room_id: room_id,
        room_temp: room_temp,
        ac_wind: ac_wind,
        ac_temp: ac_temp,
        online_time: online_time,
        checkin_time: checkin_time,
        power: power,
        expense: expense,
        charge_policy: charge_policy
      });
    }
    
  }
  
  componentWillUnmount() {
    clearInterval(this.interval_heartbeat);
  }

  start_order_timer(wind, temp) {
    let is_order_timer_on = true;
    this.setState({
      is_order_timer_on: is_order_timer_on
    });
    this.interval_order = setInterval(() => this.set_ac_mode(wind, temp), 1000);
  }

  stop_order_timer() {
    let is_order_timer_on = false;
    this.setState({
      is_order_timer_on: is_order_timer_on
    });
    clearInterval(this.interval_order);
  }

  update_room_temp() {
    if (this.state.is_served) {
      let room_temp = this.state.room_temp;
      let int = this.state.interval_update_room_temp;
      if (this.state.room_temp < this.state.ac_temp) {
        room_temp += this.state.ac_wind / (3 * int)
      } else {
        room_temp -= this.state.ac_wind / (3 * int)
      }
      this.setState({
        room_temp: room_temp.toFixed(1)
      })
    }
    else {
      let room_temp = this.state.room_temp;
      let int = this.state.interval_update_room_temp;
      if (this.state.room_temp < this.state.default_room_temp) {
        room_temp += 0.5 / (3 * int)
      } 
      else {
        room_temp -= 0.5 / (3 * int)
      }
      this.setState({
        room_temp: room_temp.toFixed(1)
      })
    }
  }

  heartbeat() {
    var request = require('superagent');
    request
      .post('http://127.0.0.1:8000/api/user/heartbeat/')
      .send({"room_id": this.state.room_id, 
            "temp": this.state.room_temp})
      .then(res => {
        this.parse_res(res);
      })
      .catch (err => {
        alert(err);
      });
    this.update_room_temp();
  }

  check_in() {
    var request = require('superagent');
    request
      .get('http://127.0.0.1:8000/api/user/checkin/')
      .then(res => {
        this.parse_res(res);
        let json = JSON.parse(res.text);
        let temp_min = json['temp_min'];
        let temp_max = json['temp_max'];
        let default_room_temp = this.state.room_temp;
        this.setState({
          temp_min: temp_min,
          temp_max: temp_max,
          default_room_temp: default_room_temp
          }); 
          this.interval_heartbeat = setInterval(() => this.heartbeat(), this.state.interval_heartbeat);
          console.log(this.state)
      })
      .catch (err => {
        alert(err)
      })
  }

  power_on_off() {
    var request = require('superagent');
    request
      .post('http://127.0.0.1:8000/api/user/setmode/')
      .send({"room_id": this.state.room_id, 
            "ac_status": this.state.is_on ? "off" : this.wind_int2str(this.state.ac_wind), 
            "target_temp": this.state.ac_temp})
      .then(res => {
        this.parse_res(res);
        let is_on = !this.state.is_on;
        this.setState({
          is_on: is_on
        })
        console.log(this.state)
      })
      .catch (err => {
        alert(err)
      })
  }

  set_ac_mode(wind, temp){
    var request = require('superagent')
    request
      .post('http://127.0.0.1:8000/api/user/setmode/')
      .send({"room_id": this.state.room_id, 
            "ac_status": wind,
            "target_temp": temp})
      .then(res => {
        this.parse_res(res);
        console.log(this.state)
      })
      .catch (err => {
        alert(err)
      })
  }

  set_temp(temp) {
    if (temp < this.state.temp_min || temp > this.state.temp_max) {
      alert('Out of temp range!');
      return;
    }
    this.setState({
      ac_temp: temp
    })
    if (this.state.is_order_timer_on) {
      this.stop_order_timer();
    }
    this.start_order_timer(this.state.ac_wind, temp);
  }

  set_wind(wind) {
    if (wind <= 0 || wind > 3) {
      alert('Out of wind range!');
      return;
    }
    let wind_type = this.wind_int2str(wind);
    this.setState({
      ac_wind: wind
    })
    if (this.state.is_order_timer_on) {
      this.stop_order_timer();
    }
    this.start_order_timer(wind_type, this.state.ac_temp);
  }

  render() {
    return (
      <div className="App">
          <div id="wrapper">
              <header id="header">
                {
                  this.state.is_checked_in ?
                    (<button className="logo" onClick={() => this.power_on_off()}>
                    <span className={"fa fa-power-off fa-2x " + (this.state.is_on ? "icon-ac-is-on" : "icon-ac-is-off")}></span>
                    </button>)
                    :
                    (<div className="logo"><span className="icon fa-gem"></span></div>)
                }
                
                <div className="content">
                  <div className="inner">
                    <h3>Welcome to 19D Hotel</h3>
                    <p>Enjoy your visit!</p>
                    {
                      this.state.is_checked_in ?
                        <div>
                          {this.state.is_on ? 
                          <div>
                            <div className="attr-box">
                              <button className="vertical-middle fa fa-minus" onClick={() => this.set_temp(this.state.ac_temp - 1.0)}></button>
                              <span className="vertical-middle text-label">{this.state.ac_temp} ℃</span>
                              <button className="vertical-middle fa fa-plus" onClick={() => this.set_temp(this.state.ac_temp + 1.0)}></button>
                            </div>
                            <p></p>
                            <div className="attr-box">
                              <button className="vertical-middle fa fa-minus" onClick={() => this.set_wind(this.state.ac_wind - 1)}></button>
                              <span className="vertical-middle text-label">{this.wind_int2str(this.state.ac_wind)} Wind</span>
                              <button className="vertical-middle fa fa-plus" onClick={() => this.set_wind(this.state.ac_wind + 1)}></button>
                            </div> 
                          </div> : <div></div>}
                          <p></p>
                          <article id="Detail">
                            <span className="image main"><img src="style/html5up-dimension/images/pic01.jpg" alt="" style={{height: 0 + 'px', width: 550 + 'px'}} /></span>
                            <h2 className="major">Detail</h2>
                            <h3>Room {this.state.room_id}</h3>
                            <h5>Now Temp: {this.state.room_temp} ℃</h5>
                            <h5>Power Count: {this.state.power} kwh</h5>
                            <h5>Expense Count: {this.state.expense} $</h5>
                          </article>
                        </div>
                      :
                        <button onClick={() => this.check_in()}>CHECK IN</button>
                    }
                  </div>
                </div>
              </header>

              <footer id="footer">
                <p className="copyright">&copy; AC REMOTE CONTROL. Design: <a href="git@39.106.86.23:/home/git/air_conditioner_system_backend">19D</a>.</p>
              </footer>
          </div>
        {/*<!-- BG -->*/}
          <div id="bg"></div>
    </div>
    );
  }
}

export default App;
